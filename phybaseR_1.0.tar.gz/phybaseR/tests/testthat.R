library(testthat)
library(phybaseR)

test_check("phybaseR")
